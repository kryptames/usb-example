package takro;

import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.FixtureDef;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;

abstract class Ball {
    protected static final float DEFAULT_DENSITY = 0.9f;
    protected static final float DEFAULT_FRICTION = 0.9f;
    protected static final float DEFAULT_RESTITUTION = 0.5f;

    private Color fillColor, strokeColor;
    protected Body body;
    
    public Ball(TakroWorld world, Vec2 pos) {
        BodyDef bd = new BodyDef();
        bd.type = BodyType.DYNAMIC;
        bd.setPosition(pos);
        this.body = world.createBody(bd);
        this.body.setUserData(this);
        setColor("grey");
    }
    protected abstract void createFixture();
    protected abstract void drawShape(GraphicsContext gc);
    public Ball setColor(String color) {
        this.strokeColor = Color.web(color);
        this.fillColor = Color.web(color,0.2);
        return this;
    }
    public Ball setSpeed(Vec2 velocity) {
        body.setLinearVelocity(velocity);
        return this;
    }
    public Ball setSpin(float w) {
        body.setAngularVelocity(w);
        return this;
    }
    public void draw(GraphicsContext gc) {
        Vec2 center = body.getPosition();
        gc.setFill(fillColor);
        gc.setStroke(strokeColor);
        gc.setLineWidth(.01);
        gc.save();
        gc.translate(center.x, center.y);
        gc.rotate(Math.toDegrees(body.getAngle()));
        drawShape(gc);
        gc.restore();
    }
}

class CircularBall extends Ball {
    private float size;
    
    public CircularBall(TakroWorld world, Vec2 pos, float size) {
        super(world,pos);
        this.size = size;
        createFixture();
    }
    protected void createFixture() {
        CircleShape shape = new CircleShape();
        shape.m_radius = size/2;
        FixtureDef fd = new FixtureDef();
        fd.shape = shape;
        fd.density = DEFAULT_DENSITY;
        fd.restitution = DEFAULT_RESTITUTION;
        fd.friction = DEFAULT_FRICTION;
        body.createFixture(fd);
    }
    protected void drawShape(GraphicsContext gc) {
        gc.fillOval(-size/2,-size/2,size,size);
        gc.strokeOval(-size/2,-size/2,size,size);
        gc.strokeLine(0, 0, size/2, 0);
    }    
}

class RectangularBall extends Ball {
    private Vec2 size;
    
    public RectangularBall(TakroWorld world, Vec2 pos, Vec2 size) {
        super(world,pos);
        this.size = size;
        createFixture();
    } 
    protected void createFixture() {
        PolygonShape shape = new PolygonShape();
        shape.setAsBox(size.x/2, size.y/2);
        FixtureDef fd = new FixtureDef();
        fd.shape = shape;
        fd.density = DEFAULT_DENSITY;
        fd.restitution = DEFAULT_RESTITUTION;
        fd.friction = DEFAULT_FRICTION;
        body.createFixture(fd);
    }
    protected void drawShape(GraphicsContext gc) {
        gc.fillRect(-size.x/2,-size.y/2,size.x,size.y);
        gc.strokeRect(-size.x/2,-size.y/2,size.x,size.y);
    }
}