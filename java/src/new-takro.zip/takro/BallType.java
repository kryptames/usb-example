package takro;

public enum BallType {
    REGULAR,
    CUBIC,
    BIG,
    FAST_SPIN,
    BRICK,
    FAST_SPIN_BRICK,
}
